#' @importFrom matrixStats rowVars rowSds
#' @importFrom matrixStats rowMeans2 rowSums2
#' @importFrom stats rnorm rgamma var density model.matrix median
#' @importFrom graphics lines plot
NULL